"""
data/dataset.py
===============
Dataset loader, preprocessing, augmentasi, dan data splitting
untuk BUSI (Breast Ultrasound Images Dataset).

Struktur folder BUSI yang diharapkan:
    dataset/BUSI/
        benign/
            benign (1).png
            benign (1)_mask.png
            ...
        malignant/
            malignant (1).png
            ...
        normal/
            normal (1).png
            ...
"""

import os
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from PIL import Image
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from torchvision import transforms

from configs.config import AugmentationConfig, DataConfig


# ─────────────────────────────────────────────
# 1. HELPER: Scan dan filter file gambar BUSI
# ─────────────────────────────────────────────

def scan_busi_dataset(root: str, class_names: List[str]) -> Tuple[List[str], List[int]]:
    """
    Scan folder BUSI dan kembalikan daftar path + label.
    File mask (mengandung '_mask') diabaikan secara otomatis.

    Returns:
        image_paths: list path gambar
        labels     : list integer label (sesuai urutan class_names)
    """
    image_paths: List[str] = []
    labels: List[int] = []

    root_path = Path(root)
    if not root_path.exists():
        raise FileNotFoundError(
            f"Dataset root tidak ditemukan: {root}\n"
            "Pastikan struktur folder: dataset/BUSI/benign/, malignant/, normal/"
        )

    for label_idx, cls in enumerate(class_names):
        class_dir = root_path / cls
        if not class_dir.exists():
            print(f"[WARN] Folder tidak ditemukan: {class_dir}")
            continue

        files = sorted(class_dir.glob("*.png")) + sorted(class_dir.glob("*.jpg"))
        img_files = [f for f in files if "_mask" not in f.name.lower()]

        print(f"  [{cls:>10}] {len(img_files):>4} images found")
        image_paths.extend([str(f) for f in img_files])
        labels.extend([label_idx] * len(img_files))

    assert len(image_paths) > 0, "Tidak ada gambar yang ditemukan! Periksa path dataset."
    return image_paths, labels


# ─────────────────────────────────────────────
# 2. TRANSFORMS
# ─────────────────────────────────────────────

def build_train_transform(cfg_data: DataConfig, cfg_aug: AugmentationConfig) -> transforms.Compose:
    """Transform untuk training (dengan augmentasi)."""
    return transforms.Compose([
        transforms.Resize(cfg_data.image_size),
        transforms.RandomHorizontalFlip(p=cfg_aug.horizontal_flip_p),
        transforms.RandomVerticalFlip(p=cfg_aug.vertical_flip_p),
        transforms.RandomRotation(degrees=cfg_aug.rotation_degrees),
        transforms.ColorJitter(
            brightness=cfg_aug.brightness,
            contrast=cfg_aug.contrast,
            saturation=cfg_aug.saturation,
        ),
        transforms.RandomApply(
            [transforms.GaussianBlur(kernel_size=3)],
            p=cfg_aug.gaussian_blur_p
        ),
        transforms.RandomApply(
            [transforms.ElasticTransform(alpha=50.0)],
            p=cfg_aug.elastic_transform_p
        ),
        transforms.ToTensor(),
        transforms.Normalize(mean=cfg_data.mean, std=cfg_data.std),
        transforms.RandomErasing(p=cfg_aug.random_erasing_p),
    ])


def build_eval_transform(cfg_data: DataConfig) -> transforms.Compose:
    """Transform untuk validation dan test (tanpa augmentasi)."""
    return transforms.Compose([
        transforms.Resize(cfg_data.image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=cfg_data.mean, std=cfg_data.std),
    ])


# ─────────────────────────────────────────────
# 3. PYTORCH DATASET
# ─────────────────────────────────────────────

class BUSIDataset(Dataset):
    """
    PyTorch Dataset untuk BUSI.
    Gambar grayscale otomatis dikonversi ke RGB (3 channel).
    """

    def __init__(
        self,
        image_paths: List[str],
        labels: List[int],
        transform: Optional[transforms.Compose] = None,
        class_names: Optional[List[str]] = None,
    ):
        self.image_paths = image_paths
        self.labels = labels
        self.transform = transform
        self.class_names = class_names or ["benign", "malignant", "normal"]

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        img_path = self.image_paths[idx]
        label = self.labels[idx]

        # Load dan konversi ke RGB (handle grayscale)
        image = Image.open(img_path).convert("RGB")

        if self.transform:
            image = self.transform(image)

        return image, label

    def get_class_counts(self) -> Dict[str, int]:
        """Hitung jumlah sampel per kelas."""
        counts = {}
        for i, cls in enumerate(self.class_names):
            counts[cls] = self.labels.count(i)
        return counts


# ─────────────────────────────────────────────
# 4. DATA SPLITTING
# ─────────────────────────────────────────────

def split_dataset(
    image_paths: List[str],
    labels: List[int],
    test_size: float = 0.20,
    val_size: float = 0.15,
    random_seed: int = 42,
) -> Tuple[List, List, List, List, List, List]:
    """
    Stratified split:
        Train : ~65% of total
        Val   : ~15% of total
        Test  : ~20% of total (independent test set)

    Returns: (train_paths, val_paths, test_paths,
               train_labels, val_labels, test_labels)
    """
    # Step 1: Pisahkan 20% test set
    train_val_paths, test_paths, train_val_labels, test_labels = train_test_split(
        image_paths, labels,
        test_size=test_size,
        stratify=labels,
        random_state=random_seed,
    )

    # Step 2: Dari sisa 80%, ambil val_size/(1-test_size) sebagai validation
    adjusted_val_size = val_size / (1.0 - test_size)
    train_paths, val_paths, train_labels, val_labels = train_test_split(
        train_val_paths, train_val_labels,
        test_size=adjusted_val_size,
        stratify=train_val_labels,
        random_state=random_seed,
    )

    print(f"\n[DataSplit] Train: {len(train_paths)} | Val: {len(val_paths)} | Test: {len(test_paths)}")
    return train_paths, val_paths, test_paths, train_labels, val_labels, test_labels


# ─────────────────────────────────────────────
# 5. WEIGHTED SAMPLER (handle class imbalance)
# ─────────────────────────────────────────────

def build_weighted_sampler(labels: List[int], num_classes: int = 3) -> WeightedRandomSampler:
    """
    Buat WeightedRandomSampler agar setiap class mendapat
    representasi yang seimbang dalam setiap batch training.
    """
    class_counts = np.bincount(labels, minlength=num_classes).astype(float)
    class_weights = 1.0 / np.where(class_counts > 0, class_counts, 1.0)
    sample_weights = torch.tensor([class_weights[l] for l in labels], dtype=torch.float)

    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True,
    )
    return sampler


# ─────────────────────────────────────────────
# 6. DATALOADER BUILDER
# ─────────────────────────────────────────────

def build_dataloaders(
    cfg_data: DataConfig,
    cfg_aug: AugmentationConfig,
    batch_size: int = 32,
    num_workers: int = 4,
    use_weighted_sampler: bool = True,
) -> Tuple[DataLoader, DataLoader, DataLoader, List[str]]:
    """
    Entry point utama: scan dataset → split → build DataLoaders.

    Returns:
        train_loader, val_loader, test_loader, class_names
    """
    print("\n[Dataset] Scanning BUSI dataset...")
    image_paths, labels = scan_busi_dataset(cfg_data.dataset_root, cfg_data.class_names)

    # Split
    (train_paths, val_paths, test_paths,
     train_labels, val_labels, test_labels) = split_dataset(
        image_paths, labels,
        test_size=cfg_data.test_size,
        val_size=cfg_data.val_size,
        random_seed=cfg_data.random_seed,
    )

    # Transforms
    train_tf = build_train_transform(cfg_data, cfg_aug)
    eval_tf  = build_eval_transform(cfg_data)

    # Datasets
    train_ds = BUSIDataset(train_paths, train_labels, train_tf, cfg_data.class_names)
    val_ds   = BUSIDataset(val_paths,   val_labels,   eval_tf,  cfg_data.class_names)
    test_ds  = BUSIDataset(test_paths,  test_labels,  eval_tf,  cfg_data.class_names)

    # Print class distribution
    print(f"\n[Dataset] Class distribution:")
    for split_name, ds in [("Train", train_ds), ("Val", val_ds), ("Test", test_ds)]:
        counts = ds.get_class_counts()
        print(f"  {split_name:>5}: {counts}")

    # Sampler
    sampler = build_weighted_sampler(train_labels) if use_weighted_sampler else None
    shuffle_train = sampler is None  # Jangan shuffle jika pakai sampler

    pin_memory = torch.cuda.is_available()

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        sampler=sampler,
        shuffle=shuffle_train,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=True,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=pin_memory,
    )

    return train_loader, val_loader, test_loader, cfg_data.class_names
