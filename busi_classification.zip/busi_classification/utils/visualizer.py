"""
utils/visualizer.py
===================
Visualisasi hasil evaluasi:
    1. Training history curves (loss & accuracy)
    2. Confusion Matrix (normalized + raw)
    3. t-SNE feature space visualization
    4. Per-class ROC curves (opsional)
"""

import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import numpy as np
import seaborn as sns
from sklearn.manifold import TSNE
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc


# Palette warna konsisten
CLASS_COLORS = ["#4CC9F0", "#F72585", "#4AD66D"]   # Benign, Malignant, Normal
DARK_BG  = "#0f0f1a"
CARD_BG  = "#1a1a2e"
TEXT_COL = "#e0e0e0"


def _apply_dark_style():
    plt.rcParams.update({
        "figure.facecolor":  DARK_BG,
        "axes.facecolor":    CARD_BG,
        "axes.edgecolor":    "#333355",
        "axes.labelcolor":   TEXT_COL,
        "xtick.color":       TEXT_COL,
        "ytick.color":       TEXT_COL,
        "text.color":        TEXT_COL,
        "grid.color":        "#333355",
        "grid.alpha":        0.5,
        "font.family":       "DejaVu Sans",
    })


# ─────────────────────────────────────────────
# 1. Training History Curves
# ─────────────────────────────────────────────

def plot_training_history(
    history: Dict[str, List],
    output_path: str = "outputs/figures/training_history.png",
):
    """Plot loss dan accuracy curves selama training."""
    _apply_dark_style()
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.patch.set_facecolor(DARK_BG)

    epochs = range(1, len(history["train_loss"]) + 1)

    # ── Loss ──
    ax = axes[0]
    ax.plot(epochs, history["train_loss"], color="#4CC9F0", lw=2, label="Train Loss")
    ax.plot(epochs, history["val_loss"],   color="#F72585", lw=2, label="Val Loss",   ls="--")
    ax.set_title("Loss Curve", fontweight="bold")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Loss")
    ax.legend(); ax.grid(True, alpha=0.3)

    # ── Accuracy ──
    ax = axes[1]
    ax.plot(epochs, [v*100 for v in history["train_acc"]], color="#4CC9F0", lw=2, label="Train Acc")
    ax.plot(epochs, [v*100 for v in history["val_acc"]],   color="#F72585", lw=2, label="Val Acc", ls="--")
    ax.set_title("Accuracy Curve", fontweight="bold")
    ax.set_xlabel("Epoch"); ax.set_ylabel("Accuracy (%)")
    ax.legend(); ax.grid(True, alpha=0.3)

    # ── Learning Rate ──
    ax = axes[2]
    ax.plot(epochs, history["lr"], color="#4AD66D", lw=2)
    ax.set_title("Learning Rate Schedule", fontweight="bold")
    ax.set_xlabel("Epoch"); ax.set_ylabel("LR")
    ax.set_yscale("log"); ax.grid(True, alpha=0.3)

    plt.suptitle("Training History", fontsize=14, fontweight="bold", y=1.01)
    plt.tight_layout()
    _save_fig(fig, output_path)


# ─────────────────────────────────────────────
# 2. Confusion Matrix
# ─────────────────────────────────────────────

def plot_confusion_matrix(
    cm: np.ndarray,
    class_names: List[str],
    output_path: str = "outputs/figures/confusion_matrix.png",
    normalize: bool = True,
):
    """
    Plot confusion matrix (normalized + raw count side by side).
    """
    _apply_dark_style()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
    fig.patch.set_facecolor(DARK_BG)

    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)

    for ax, data, title, fmt in [
        (axes[0], cm_norm, "Normalized", ".2f"),
        (axes[1], cm,      "Raw Count",  "d"),
    ]:
        cmap = sns.diverging_palette(220, 20, as_cmap=True)
        sns.heatmap(
            data,
            ax=ax,
            annot=True,
            fmt=fmt,
            cmap="Blues",
            xticklabels=class_names,
            yticklabels=class_names,
            linewidths=0.5,
            linecolor="#333355",
            cbar_kws={"shrink": 0.8},
        )
        ax.set_title(f"Confusion Matrix ({title})", fontweight="bold", pad=10)
        ax.set_xlabel("Predicted", fontsize=11)
        ax.set_ylabel("Actual", fontsize=11)
        ax.tick_params(axis="x", rotation=30)
        ax.tick_params(axis="y", rotation=0)

    # Per-class accuracy annotation
    per_class_acc = cm.diagonal() / cm.sum(axis=1)
    ann_text = " | ".join(
        f"{cls}: {acc*100:.1f}%"
        for cls, acc in zip(class_names, per_class_acc)
    )
    fig.text(
        0.5, -0.02, f"Per-class Accuracy: {ann_text}",
        ha="center", fontsize=10, color=TEXT_COL,
    )

    plt.suptitle("Confusion Matrix — BUSI Test Set", fontsize=13, fontweight="bold")
    plt.tight_layout()
    _save_fig(fig, output_path)


# ─────────────────────────────────────────────
# 3. t-SNE Feature Visualization
# ─────────────────────────────────────────────

def plot_tsne(
    features: np.ndarray,
    labels: List[int],
    class_names: List[str],
    preds: Optional[List[int]] = None,
    output_path: str = "outputs/figures/tsne.png",
    perplexity: int = 30,
    n_iter: int = 1000,
    random_state: int = 42,
):
    """
    Visualisasi t-SNE dari feature space.
    Jika preds diberikan, tampilkan juga panel prediksi vs ground truth.
    """
    _apply_dark_style()
    print(f"[t-SNE] Computing t-SNE (perplexity={perplexity}, n_iter={n_iter})...")

    tsne = TSNE(
        n_components=2,
        perplexity=perplexity,
        n_iter=n_iter,
        random_state=random_state,
        verbose=0,
    )
    emb = tsne.fit_transform(features)

    ncols = 2 if preds is not None else 1
    fig, axes = plt.subplots(1, ncols, figsize=(8 * ncols, 7))
    fig.patch.set_facecolor(DARK_BG)
    if ncols == 1:
        axes = [axes]

    labels_arr = np.array(labels)

    def _scatter(ax, color_labels, title, subtitle=""):
        for i, (cls, color) in enumerate(zip(class_names, CLASS_COLORS)):
            mask = color_labels == i
            ax.scatter(
                emb[mask, 0], emb[mask, 1],
                c=color, label=cls,
                s=28, alpha=0.75, edgecolors="none",
            )
        ax.set_title(title, fontweight="bold", fontsize=13, pad=8)
        if subtitle:
            ax.set_title(f"{title}\n{subtitle}", fontweight="bold", fontsize=11, pad=8)
        ax.legend(
            title="Class", loc="upper right",
            framealpha=0.3, facecolor=CARD_BG,
            labelcolor=TEXT_COL,
        )
        ax.set_xlabel("t-SNE dim 1"); ax.set_ylabel("t-SNE dim 2")
        ax.grid(True, alpha=0.2)

    _scatter(axes[0], labels_arr, "t-SNE — Ground Truth")

    if preds is not None:
        preds_arr = np.array(preds)
        _scatter(axes[1], preds_arr, "t-SNE — Model Predictions")

        # Highlight misclassifications
        wrong = preds_arr != labels_arr
        if wrong.sum() > 0:
            axes[1].scatter(
                emb[wrong, 0], emb[wrong, 1],
                c="red", marker="x", s=60, linewidths=1.5,
                label=f"Misclassified ({wrong.sum()})", zorder=5,
            )
            axes[1].legend(
                title="Class", loc="upper right",
                framealpha=0.3, facecolor=CARD_BG,
                labelcolor=TEXT_COL,
            )

    plt.suptitle(
        "t-SNE Feature Space — EfficientNetV2-S",
        fontsize=14, fontweight="bold",
    )
    plt.tight_layout()
    _save_fig(fig, output_path)


# ─────────────────────────────────────────────
# 4. ROC Curves
# ─────────────────────────────────────────────

def plot_roc_curves(
    all_labels: List[int],
    all_probs: np.ndarray,
    class_names: List[str],
    output_path: str = "outputs/figures/roc_curves.png",
):
    """Plot one-vs-rest ROC curves per kelas."""
    _apply_dark_style()
    fig, ax = plt.subplots(figsize=(8, 6))
    fig.patch.set_facecolor(DARK_BG)

    n_classes = len(class_names)
    labels_bin = label_binarize(all_labels, classes=list(range(n_classes)))

    for i, (cls, color) in enumerate(zip(class_names, CLASS_COLORS)):
        fpr, tpr, _ = roc_curve(labels_bin[:, i], all_probs[:, i])
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, color=color, lw=2, label=f"{cls} (AUC={roc_auc:.3f})")

    ax.plot([0, 1], [0, 1], "--", color="#555577", lw=1, label="Random")
    ax.set_xlim([0, 1]); ax.set_ylim([0, 1.02])
    ax.set_xlabel("False Positive Rate", fontsize=11)
    ax.set_ylabel("True Positive Rate", fontsize=11)
    ax.set_title("ROC Curves — One-vs-Rest", fontweight="bold", fontsize=13)
    ax.legend(framealpha=0.3, facecolor=CARD_BG, labelcolor=TEXT_COL)
    ax.grid(True, alpha=0.25)

    plt.tight_layout()
    _save_fig(fig, output_path)


# ─────────────────────────────────────────────
# 5. Summary Dashboard
# ─────────────────────────────────────────────

def plot_metrics_summary(
    metrics: Dict,
    class_names: List[str],
    output_path: str = "outputs/figures/metrics_summary.png",
):
    """Bar chart ringkasan metrik per kelas."""
    _apply_dark_style()
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    fig.patch.set_facecolor(DARK_BG)

    metric_names = ["precision", "recall", "f1"]
    metric_labels = ["Precision", "Recall", "F1-Score"]

    for ax, metric, label in zip(axes, metric_names, metric_labels):
        values = [metrics["per_class"][cls][metric] * 100 for cls in class_names]
        bars = ax.bar(class_names, values, color=CLASS_COLORS, edgecolor="#333355", linewidth=0.5)

        for bar, val in zip(bars, values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.5,
                f"{val:.1f}%",
                ha="center", va="bottom", fontsize=10, color=TEXT_COL,
            )

        ax.set_ylim(0, 115)
        ax.set_title(f"{label} per Class", fontweight="bold")
        ax.set_ylabel(f"{label} (%)")
        ax.grid(axis="y", alpha=0.3)
        ax.tick_params(axis="x", rotation=15)

    # Annotasi overall metrics
    overall = (
        f"Accuracy: {metrics['accuracy']*100:.2f}% | "
        f"F1-Macro: {metrics['f1_macro']*100:.2f}% | "
        f"MCC: {metrics['mcc']:.4f} | "
        f"AUC: {metrics['auc_macro']:.4f}"
    )
    fig.text(0.5, -0.04, overall, ha="center", fontsize=11, color="#4CC9F0", fontweight="bold")

    plt.suptitle("Evaluation Metrics Summary — BUSI Test Set", fontsize=13, fontweight="bold")
    plt.tight_layout()
    _save_fig(fig, output_path)


# ─────────────────────────────────────────────
# 6. Helper
# ─────────────────────────────────────────────

def _save_fig(fig, output_path: str):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.savefig(output_path, dpi=150, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"[Visualizer] Saved → {output_path}")
