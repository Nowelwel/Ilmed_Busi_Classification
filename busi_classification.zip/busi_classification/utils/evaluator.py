"""
utils/evaluator.py
==================
Evaluasi model pada independent test set.

Metrik yang dihitung:
    - Accuracy
    - Precision, Recall, F1-score (per kelas + macro/weighted)
    - Matthews Correlation Coefficient (MCC)
    - Confusion Matrix
    - Per-class AUC-ROC (one-vs-rest)
"""

from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    matthews_corrcoef,
    precision_recall_fscore_support,
    roc_auc_score,
)
from torch.utils.data import DataLoader


# ─────────────────────────────────────────────
# 1. Inference: Kumpulkan prediksi dari DataLoader
# ─────────────────────────────────────────────

@torch.no_grad()
def collect_predictions(
    model: nn.Module,
    loader: DataLoader,
    device: torch.device,
    return_features: bool = False,
) -> Tuple:
    """
    Jalankan inference pada seluruh DataLoader.

    Returns:
        all_preds   : list prediksi kelas (int)
        all_labels  : list ground truth (int)
        all_probs   : array probabilitas (N, C)
        all_features: array fitur sebelum classifier (N, D) — jika return_features=True
    """
    model.eval()
    all_preds, all_labels, all_probs = [], [], []
    all_features = [] if return_features else None

    for images, labels in loader:
        images = images.to(device, non_blocking=True)

        logits = model(images)
        probs = torch.softmax(logits, dim=1)
        preds = logits.argmax(dim=1)

        all_preds.extend(preds.cpu().tolist())
        all_labels.extend(labels.tolist())
        all_probs.append(probs.cpu().numpy())

        # Ekstrak fitur untuk t-SNE (sebelum classifier head)
        if return_features:
            with torch.no_grad():
                feats = model.features(images)
                feats = model.avgpool(feats)
                feats = torch.flatten(feats, 1)
            all_features.append(feats.cpu().numpy())

    all_probs_arr = np.vstack(all_probs)
    all_features_arr = np.vstack(all_features) if return_features else None

    return all_preds, all_labels, all_probs_arr, all_features_arr


# ─────────────────────────────────────────────
# 2. Hitung semua metrik evaluasi
# ─────────────────────────────────────────────

def compute_metrics(
    all_preds: List[int],
    all_labels: List[int],
    all_probs: np.ndarray,
    class_names: List[str],
    verbose: bool = True,
) -> Dict:
    """
    Hitung accuracy, precision, recall, F1, MCC, AUC-ROC.

    Args:
        all_preds : Prediksi model (N,)
        all_labels: Ground truth (N,)
        all_probs : Probabilitas kelas (N, C)
        class_names: Nama kelas
    Returns:
        metrics: dict berisi semua metrik
    """
    all_preds_arr  = np.array(all_preds)
    all_labels_arr = np.array(all_labels)

    # ── Accuracy ──
    accuracy = accuracy_score(all_labels_arr, all_preds_arr)

    # ── Precision, Recall, F1 ──
    precision_per_class, recall_per_class, f1_per_class, support = \
        precision_recall_fscore_support(all_labels_arr, all_preds_arr, average=None, zero_division=0)

    precision_macro = np.mean(precision_per_class)
    recall_macro    = np.mean(recall_per_class)
    f1_macro        = np.mean(f1_per_class)

    precision_w, recall_w, f1_w, _ = precision_recall_fscore_support(
        all_labels_arr, all_preds_arr, average="weighted", zero_division=0
    )

    # ── MCC ──
    mcc = matthews_corrcoef(all_labels_arr, all_preds_arr)

    # ── Confusion Matrix ──
    cm = confusion_matrix(all_labels_arr, all_preds_arr)

    # ── AUC-ROC (one-vs-rest) ──
    try:
        auc_macro = roc_auc_score(
            all_labels_arr, all_probs, multi_class="ovr", average="macro"
        )
    except Exception:
        auc_macro = float("nan")

    metrics = {
        "accuracy":          accuracy,
        "precision_macro":   precision_macro,
        "recall_macro":      recall_macro,
        "f1_macro":          f1_macro,
        "precision_weighted": precision_w,
        "recall_weighted":   recall_w,
        "f1_weighted":       f1_w,
        "mcc":               mcc,
        "auc_macro":         auc_macro,
        "confusion_matrix":  cm,
        "per_class": {
            cls: {
                "precision": float(precision_per_class[i]),
                "recall":    float(recall_per_class[i]),
                "f1":        float(f1_per_class[i]),
                "support":   int(support[i]),
            }
            for i, cls in enumerate(class_names)
        },
    }

    if verbose:
        _print_metrics(metrics, class_names)

    return metrics


def _print_metrics(metrics: Dict, class_names: List[str]):
    """Print ringkasan metrik ke konsol."""
    sep = "─" * 55
    print(f"\n{sep}")
    print(f"{'EVALUATION RESULTS':^55}")
    print(sep)
    print(f"  Accuracy  : {metrics['accuracy']*100:>6.2f}%")
    print(f"  F1 Macro  : {metrics['f1_macro']*100:>6.2f}%")
    print(f"  F1 Weighted: {metrics['f1_weighted']*100:>5.2f}%")
    print(f"  Precision (macro): {metrics['precision_macro']*100:>6.2f}%")
    print(f"  Recall    (macro): {metrics['recall_macro']*100:>6.2f}%")
    print(f"  MCC       : {metrics['mcc']:>8.4f}")
    print(f"  AUC-ROC   : {metrics['auc_macro']:>8.4f}")
    print(sep)
    print(f"\n  Per-Class Breakdown:")
    print(f"  {'Class':>12}  {'Precision':>10}  {'Recall':>8}  {'F1':>8}  {'Support':>8}")
    print(f"  {'─'*12}  {'─'*10}  {'─'*8}  {'─'*8}  {'─'*8}")
    for cls in class_names:
        pc = metrics["per_class"][cls]
        print(
            f"  {cls:>12}  {pc['precision']*100:>9.2f}%  "
            f"{pc['recall']*100:>7.2f}%  {pc['f1']*100:>7.2f}%  {pc['support']:>8}"
        )
    print(sep)


# ─────────────────────────────────────────────
# 3. Full Evaluation Pipeline
# ─────────────────────────────────────────────

def evaluate_model(
    model: nn.Module,
    test_loader: DataLoader,
    class_names: List[str],
    device: Optional[torch.device] = None,
    return_features: bool = True,
) -> Dict:
    """
    Entry point evaluasi: inference + hitung semua metrik.

    Returns:
        results: dict berisi metrik + prediksi + fitur
    """
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"\n[Evaluator] Running inference on test set ({device})...")

    all_preds, all_labels, all_probs, all_features = collect_predictions(
        model, test_loader, device, return_features=return_features
    )

    metrics = compute_metrics(all_preds, all_labels, all_probs, class_names)

    return {
        "metrics":      metrics,
        "all_preds":    all_preds,
        "all_labels":   all_labels,
        "all_probs":    all_probs,
        "all_features": all_features,   # Digunakan untuk t-SNE
    }
