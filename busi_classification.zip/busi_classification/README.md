# BUSI Breast Cancer Classification
### EfficientNetV2-S · PyTorch · From Scratch · 3-Class

Pipeline klasifikasi ultrasound payudara berbasis **BUSI Dataset** menggunakan **EfficientNetV2-S** yang dilatih dari nol (tanpa pretrained weights, tanpa ViT).

---

## Struktur Project

```
busi_classification/
├── configs/
│   └── config.py           # Semua hyperparameter & konfigurasi
├── data/
│   └── dataset.py          # Dataset loader, augmentasi, data splitting
├── models/
│   ├── efficientnet_v2.py  # Arsitektur EfficientNetV2-S dari scratch
│   └── losses.py           # Focal Loss + Class-Balanced Focal Loss
├── utils/
│   ├── trainer.py          # Training engine (AMP, early stopping, checkpointing)
│   ├── evaluator.py        # Evaluasi metrik (Accuracy, F1, MCC, AUC-ROC)
│   ├── visualizer.py       # Confusion matrix, t-SNE, ROC curves
│   └── gradcam.py          # Grad-CAM visualization
├── train.py                # Entry point training + evaluasi
├── predict.py              # Inference single image / folder
└── requirements.txt
```

---

## Dataset Setup

Unduh BUSI Dataset dan atur struktur folder:

```
dataset/
└── BUSI/
    ├── benign/
    │   ├── benign (1).png
    │   ├── benign (1)_mask.png   ← mask otomatis diabaikan
    │   └── ...
    ├── malignant/
    │   └── ...
    └── normal/
        └── ...
```

> Dataset BUSI tersedia di: https://www.kaggle.com/datasets/aryashah2k/breast-ultrasound-images-dataset

---

## Instalasi

```bash
pip install -r requirements.txt
```

---

## Training

```bash
# Training dasar (gunakan path default)
python train.py

# Custom path dan hyperparameter
python train.py \
  --dataset_root dataset/BUSI \
  --epochs 50 \
  --batch_size 32 \
  --lr 1e-4 \
  --output_dir outputs/
```

### Output Training
```
outputs/
├── checkpoints/
│   ├── best_model.pth       # Model terbaik (val_loss terendah)
│   └── last_model.pth       # Checkpoint terakhir
├── figures/
│   ├── training_history.png # Loss & accuracy curves
│   ├── confusion_matrix.png # Normalized + raw count
│   ├── tsne.png             # t-SNE feature space
│   ├── roc_curves.png       # Per-class ROC curves
│   ├── metrics_summary.png  # Bar chart metrik per kelas
│   └── gradcam.png          # Grad-CAM heatmaps
├── training_history.json
└── test_metrics.json
```

---

## Evaluasi Saja (skip training)

```bash
python train.py --skip_train --output_dir outputs/
```

---

## Inference

```bash
# Satu gambar
python predict.py --image path/to/ultrasound.png

# Batch folder
python predict.py --folder dataset/BUSI/malignant/ --output_csv results.csv
```

---

## Arsitektur Model

```
Input (B × 3 × 224 × 224)
    │
    ▼
EfficientNetV2-S Features
(MBConv + Fused-MBConv blocks)
    │
    ▼
AdaptiveAvgPool2d(1,1)  ← Global Average Pooling
    │
    ▼  (B × 1280)
Dropout(0.4)
    │
Linear(1280 → 512) + SiLU + BatchNorm1d
    │
Dropout(0.2)
    │
Linear(512 → 3)
    │
    ▼
Output Logits (B × 3)
→ Softmax → [P(benign), P(malignant), P(normal)]
```

**Inisialisasi bobot:** Kaiming Normal (Conv), Xavier Truncated Normal (Linear).
**Tidak ada pretrained weights. Tidak ada ViT.**

---

## Pipeline

```
BUSI Dataset (780 images PNG)
    │
    ▼
Load Image → Convert to RGB → Resize 224×224
    │
    ▼ (Stratified Split)
┌─────────────────────────────┐
│  Train (~65%)               │ ← Augmentasi: flip, rotate, jitter,
│  Validation (~15%)          │   elastic transform, random erasing
│  Test (~20%) — independent  │ ← No augmentasi
└─────────────────────────────┘
    │
    ▼
WeightedRandomSampler (handle imbalance)
    │
    ▼
EfficientNetV2-S (from scratch)
    │
    ▼
AdamW + CosineAnnealingLR + Early Stopping
+ Class-Balanced Focal Loss (γ=2.0)
    │
    ▼
Evaluation: Accuracy · Precision · Recall · F1 · MCC · AUC-ROC
    │
    ▼
Confusion Matrix | t-SNE | Grad-CAM
```

---

## Konfigurasi Default

| Parameter         | Nilai         |
|-------------------|---------------|
| Input size        | 224 × 224     |
| Batch size        | 32            |
| Learning rate     | 1e-4          |
| Optimizer         | AdamW         |
| Scheduler         | CosineAnnealingLR |
| Loss              | Class-Balanced Focal Loss |
| Focal gamma       | 2.0           |
| Epochs            | 50 (+ early stopping) |
| Early stop patience | 10 epochs   |
| Dropout           | 0.4           |
| Train/Val/Test    | 65% / 15% / 20% |

---

## Kelas

| Label | Kelas     | Jumlah (BUSI) |
|-------|-----------|---------------|
| 0     | Benign    | 437           |
| 1     | Malignant | 210           |
| 2     | Normal    | 133           |

---

## Reproducibility

Semua random seed dikontrol via `set_seed(42)`:
- Python `random`, NumPy, PyTorch (CPU + CUDA)
- `torch.backends.cudnn.deterministic = True`
- Stratified split dengan `random_state=42`
