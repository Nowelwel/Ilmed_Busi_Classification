"""
models/losses.py
================
Implementasi Focal Loss untuk menangani class imbalance pada BUSI.

Focal Loss: FL(p_t) = -alpha_t * (1 - p_t)^gamma * log(p_t)
    - gamma > 0: kurangi bobot easy examples
    - alpha: class weight balancing

Referensi: Lin et al., "Focal Loss for Dense Object Detection" (RetinaNet)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class FocalLoss(nn.Module):
    """
    Focal Loss untuk multi-class classification.

    Args:
        alpha  : Weighting factor. Float (uniform) atau Tensor (per-class).
        gamma  : Focusing parameter. Default 2.0.
        reduction: 'mean' | 'sum' | 'none'
        ignore_index: Label yang diabaikan saat komputasi.
    """

    def __init__(
        self,
        alpha: float = 1.0,
        gamma: float = 2.0,
        reduction: str = "mean",
        ignore_index: int = -100,
    ):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.ignore_index = ignore_index

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            inputs : Logits (B, C) — belum di-softmax
            targets: Ground truth label (B,)
        Returns:
            Scalar loss
        """
        # Cross entropy per-sample (log-softmax + NLLLoss)
        ce_loss = F.cross_entropy(
            inputs, targets,
            reduction="none",
            ignore_index=self.ignore_index,
        )

        # p_t = exp(-ce_loss) = probability dari kelas yang benar
        p_t = torch.exp(-ce_loss)

        # Focal weight: (1 - p_t)^gamma
        focal_weight = (1.0 - p_t) ** self.gamma

        # Focal loss
        focal_loss = self.alpha * focal_weight * ce_loss

        if self.reduction == "mean":
            return focal_loss.mean()
        elif self.reduction == "sum":
            return focal_loss.sum()
        else:
            return focal_loss


class ClassBalancedFocalLoss(nn.Module):
    """
    Focal Loss dengan per-class alpha dihitung dari distribusi kelas
    menggunakan formula effective number of samples.

    Referensi: Cui et al., "Class-Balanced Loss Based on Effective Number of Samples"
    """

    def __init__(
        self,
        samples_per_class: list,
        beta: float = 0.9999,
        gamma: float = 2.0,
        reduction: str = "mean",
    ):
        super().__init__()
        self.gamma = gamma
        self.reduction = reduction

        # Hitung effective number per kelas
        effective_num = 1.0 - torch.tensor(
            [beta ** n for n in samples_per_class], dtype=torch.float
        )
        # Per-class weight (alpha)
        weights = (1.0 - beta) / effective_num
        weights = weights / weights.sum() * len(samples_per_class)

        self.register_buffer("alpha_per_class", weights)

    def forward(self, inputs: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        # Ambil alpha untuk setiap sample berdasarkan label-nya
        alpha_t = self.alpha_per_class[targets]

        # CE per-sample
        ce_loss = F.cross_entropy(inputs, targets, reduction="none")

        # Focal weight
        p_t = torch.exp(-ce_loss)
        focal_loss = alpha_t * (1.0 - p_t) ** self.gamma * ce_loss

        if self.reduction == "mean":
            return focal_loss.mean()
        elif self.reduction == "sum":
            return focal_loss.sum()
        return focal_loss


def build_loss(
    alpha: float = 1.0,
    gamma: float = 2.0,
    samples_per_class: Optional[list] = None,
    use_class_balanced: bool = False,
) -> nn.Module:
    """
    Factory function untuk loss.

    Args:
        alpha: Scalar alpha untuk FocalLoss standar.
        gamma: Focusing parameter.
        samples_per_class: Jumlah sampel per kelas (untuk ClassBalancedFocalLoss).
        use_class_balanced: Gunakan ClassBalancedFocalLoss jika True.
    """
    if use_class_balanced and samples_per_class is not None:
        print(f"[Loss] ClassBalancedFocalLoss | gamma={gamma}")
        return ClassBalancedFocalLoss(
            samples_per_class=samples_per_class,
            gamma=gamma,
        )
    else:
        print(f"[Loss] FocalLoss | alpha={alpha}, gamma={gamma}")
        return FocalLoss(alpha=alpha, gamma=gamma)
